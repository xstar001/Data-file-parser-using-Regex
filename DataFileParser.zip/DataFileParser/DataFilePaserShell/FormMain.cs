﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataFileParser;
namespace DataFilePaserShell
{
    public partial class Form1 : Form
    {
        string fmt = "0.00000000";
        string m_FName = "";
        CDataFileParser dataFileParser = new CDataFileParser();
        public Form1()
        {
            InitializeComponent();
            dataFileParser.OpenConsole();
            button_Parse.Enabled = false;
            textBox_Regex.Text = dataFileParser.GetRegex();
        }

        private void button_Browse_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofdlg = new OpenFileDialog();
            if (ofdlg.ShowDialog() != DialogResult.OK) return;
            m_FName = ofdlg.FileName;
            textBox_FileName.Text = m_FName;
            button_Parse.Enabled = true;
        }

        private void button_Parse_Click(object sender, EventArgs e)
        {
            double data = 0;
            int istart = 0;
            int iend = 0;
            int i = 0;
            string[] matches = null;
            string lines = "";
            istart = Convert.ToInt32(textBox_StartLine.Text);
            iend = Convert.ToInt32(textBox_EndLine.Text);
            dataFileParser.SetLineRange(istart,iend);
            dataFileParser.ParseFile(m_FName, 0);
            textBox_DataEntries.Text = "";
            //检查数据项：
            int ndata = dataFileParser.GetDataCount();
            matches = dataFileParser.GetMatches();
            if (ndata == 0 || matches == null)
            {
                textBox_DataEntries.Text = "★ No data items found! ";
                textBox_Matches.Text = "★ No matches found! ";
                return;
            }
            //输出Regex找到的数据：
            lines = "★ " + ndata.ToString() + " data entries found in the data file: \r\n";
            for (i = 0; i < ndata; i++)
            {
                data = dataFileParser.GetDataI(i);
                lines = lines + "\t" + data.ToString(fmt);
                if (((i + 1) % 5) == 0) lines = lines + "\r\n";
            }
            textBox_DataEntries.Text = lines;
            //输出Regex找到的匹配内容：
            lines = "";
            lines = "★ " + matches.Length.ToString() + " matches found in the data file: \r\n";
            for (i = 0; i < matches.Length; i++)
            {
                lines = lines + "\t" + matches[i];
                if (((i + 1) % 5) == 0) lines = lines + "\r\n";
            }
            textBox_Matches.Text = lines;
        }

        private void button_Help_Click(object sender, EventArgs e)
        {
            dataFileParser.Help();
        }

        private void button_Close_Click(object sender, EventArgs e)
        {
            dataFileParser.CloseConsole();
            this.Close();
        }

        private void button_SetRegex_Click(object sender, EventArgs e)
        {
            dataFileParser.SetRegex(textBox_Regex.Text);
        }

        private void button_ResetRegex_Click(object sender, EventArgs e)
        {
            string regex = dataFileParser.GetDefaultRegex();
            textBox_Regex.Text = regex;
            dataFileParser.SetDefaultRegex();
        }

        private void textBox_Regex_TextChanged(object sender, EventArgs e)
        {
            dataFileParser.SetRegex(textBox_Regex.Text);
        }
    }
}
