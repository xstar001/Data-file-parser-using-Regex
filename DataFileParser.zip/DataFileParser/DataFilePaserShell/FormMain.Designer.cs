﻿
namespace DataFilePaserShell
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button_Browse = new System.Windows.Forms.Button();
            this.textBox_FileName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_StartLine = new System.Windows.Forms.TextBox();
            this.button_Parse = new System.Windows.Forms.Button();
            this.button_Help = new System.Windows.Forms.Button();
            this.button_Close = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_Regex = new System.Windows.Forms.TextBox();
            this.button_ResetRegex = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.textBox_DataEntries = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.textBox_Matches = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_EndLine = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_Browse
            // 
            this.button_Browse.BackColor = System.Drawing.Color.Blue;
            this.button_Browse.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Browse.ForeColor = System.Drawing.Color.Yellow;
            this.button_Browse.Location = new System.Drawing.Point(909, 27);
            this.button_Browse.Name = "button_Browse";
            this.button_Browse.Size = new System.Drawing.Size(33, 23);
            this.button_Browse.TabIndex = 0;
            this.button_Browse.Text = "...";
            this.button_Browse.UseVisualStyleBackColor = false;
            this.button_Browse.Click += new System.EventHandler(this.button_Browse_Click);
            // 
            // textBox_FileName
            // 
            this.textBox_FileName.BackColor = System.Drawing.Color.White;
            this.textBox_FileName.ForeColor = System.Drawing.SystemColors.WindowText;
            this.textBox_FileName.Location = new System.Drawing.Point(12, 27);
            this.textBox_FileName.Name = "textBox_FileName";
            this.textBox_FileName.ReadOnly = true;
            this.textBox_FileName.Size = new System.Drawing.Size(891, 23);
            this.textBox_FileName.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Load data file: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "Start line:";
            // 
            // textBox_StartLine
            // 
            this.textBox_StartLine.BackColor = System.Drawing.Color.White;
            this.textBox_StartLine.ForeColor = System.Drawing.SystemColors.WindowText;
            this.textBox_StartLine.Location = new System.Drawing.Point(76, 57);
            this.textBox_StartLine.Name = "textBox_StartLine";
            this.textBox_StartLine.Size = new System.Drawing.Size(61, 23);
            this.textBox_StartLine.TabIndex = 6;
            this.textBox_StartLine.Text = "0";
            this.textBox_StartLine.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button_Parse
            // 
            this.button_Parse.BackColor = System.Drawing.Color.Blue;
            this.button_Parse.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Parse.ForeColor = System.Drawing.Color.Yellow;
            this.button_Parse.Location = new System.Drawing.Point(582, 57);
            this.button_Parse.Name = "button_Parse";
            this.button_Parse.Size = new System.Drawing.Size(75, 23);
            this.button_Parse.TabIndex = 7;
            this.button_Parse.Text = "Parse";
            this.button_Parse.UseVisualStyleBackColor = false;
            this.button_Parse.Click += new System.EventHandler(this.button_Parse_Click);
            // 
            // button_Help
            // 
            this.button_Help.BackColor = System.Drawing.Color.Blue;
            this.button_Help.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Help.ForeColor = System.Drawing.Color.Yellow;
            this.button_Help.Location = new System.Drawing.Point(786, 57);
            this.button_Help.Name = "button_Help";
            this.button_Help.Size = new System.Drawing.Size(75, 23);
            this.button_Help.TabIndex = 8;
            this.button_Help.Text = "Help";
            this.button_Help.UseVisualStyleBackColor = false;
            this.button_Help.Click += new System.EventHandler(this.button_Help_Click);
            // 
            // button_Close
            // 
            this.button_Close.BackColor = System.Drawing.Color.Blue;
            this.button_Close.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Close.ForeColor = System.Drawing.Color.Yellow;
            this.button_Close.Location = new System.Drawing.Point(867, 57);
            this.button_Close.Name = "button_Close";
            this.button_Close.Size = new System.Drawing.Size(75, 23);
            this.button_Close.TabIndex = 9;
            this.button_Close.Text = "Close";
            this.button_Close.UseVisualStyleBackColor = false;
            this.button_Close.Click += new System.EventHandler(this.button_Close_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(280, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 17);
            this.label4.TabIndex = 10;
            this.label4.Text = "Current regex: ";
            // 
            // textBox_Regex
            // 
            this.textBox_Regex.BackColor = System.Drawing.Color.White;
            this.textBox_Regex.Font = new System.Drawing.Font("Microsoft YaHei UI Light", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.textBox_Regex.ForeColor = System.Drawing.Color.Blue;
            this.textBox_Regex.Location = new System.Drawing.Point(381, 57);
            this.textBox_Regex.Name = "textBox_Regex";
            this.textBox_Regex.Size = new System.Drawing.Size(195, 23);
            this.textBox_Regex.TabIndex = 11;
            this.textBox_Regex.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox_Regex.TextChanged += new System.EventHandler(this.textBox_Regex_TextChanged);
            // 
            // button_ResetRegex
            // 
            this.button_ResetRegex.BackColor = System.Drawing.Color.Blue;
            this.button_ResetRegex.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ResetRegex.ForeColor = System.Drawing.Color.Yellow;
            this.button_ResetRegex.Location = new System.Drawing.Point(662, 57);
            this.button_ResetRegex.Name = "button_ResetRegex";
            this.button_ResetRegex.Size = new System.Drawing.Size(118, 23);
            this.button_ResetRegex.TabIndex = 13;
            this.button_ResetRegex.Text = "Reset Regex";
            this.button_ResetRegex.UseVisualStyleBackColor = false;
            this.button_ResetRegex.Click += new System.EventHandler(this.button_ResetRegex_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tabControl1.Location = new System.Drawing.Point(8, 86);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(934, 422);
            this.tabControl1.TabIndex = 14;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.textBox_DataEntries);
            this.tabPage1.Location = new System.Drawing.Point(4, 26);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(926, 392);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Data entries";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // textBox_DataEntries
            // 
            this.textBox_DataEntries.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.textBox_DataEntries.Location = new System.Drawing.Point(3, 6);
            this.textBox_DataEntries.Multiline = true;
            this.textBox_DataEntries.Name = "textBox_DataEntries";
            this.textBox_DataEntries.ReadOnly = true;
            this.textBox_DataEntries.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox_DataEntries.Size = new System.Drawing.Size(917, 379);
            this.textBox_DataEntries.TabIndex = 5;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.textBox_Matches);
            this.tabPage2.Location = new System.Drawing.Point(4, 26);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(926, 392);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Matches found by regex";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // textBox_Matches
            // 
            this.textBox_Matches.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.textBox_Matches.Location = new System.Drawing.Point(5, 7);
            this.textBox_Matches.Multiline = true;
            this.textBox_Matches.Name = "textBox_Matches";
            this.textBox_Matches.ReadOnly = true;
            this.textBox_Matches.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox_Matches.Size = new System.Drawing.Size(915, 379);
            this.textBox_Matches.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(143, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 17);
            this.label2.TabIndex = 15;
            this.label2.Text = "End line:";
            // 
            // textBox_EndLine
            // 
            this.textBox_EndLine.BackColor = System.Drawing.Color.White;
            this.textBox_EndLine.ForeColor = System.Drawing.SystemColors.WindowText;
            this.textBox_EndLine.Location = new System.Drawing.Point(206, 56);
            this.textBox_EndLine.Name = "textBox_EndLine";
            this.textBox_EndLine.Size = new System.Drawing.Size(61, 23);
            this.textBox_EndLine.TabIndex = 16;
            this.textBox_EndLine.Text = "0";
            this.textBox_EndLine.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(949, 509);
            this.Controls.Add(this.textBox_EndLine);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.button_ResetRegex);
            this.Controls.Add(this.textBox_Regex);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button_Close);
            this.Controls.Add(this.button_Help);
            this.Controls.Add(this.button_Parse);
            this.Controls.Add(this.textBox_StartLine);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox_FileName);
            this.Controls.Add(this.button_Browse);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Universal data file parser using Regex (ver 2022.05.25. By Hu Yu, NWPU)";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_Browse;
        private System.Windows.Forms.TextBox textBox_FileName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_StartLine;
        private System.Windows.Forms.Button button_Parse;
        private System.Windows.Forms.Button button_Help;
        private System.Windows.Forms.Button button_Close;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_Regex;
        private System.Windows.Forms.Button button_ResetRegex;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox textBox_DataEntries;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox textBox_Matches;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_EndLine;
    }
}

