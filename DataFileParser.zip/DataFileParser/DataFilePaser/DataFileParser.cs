﻿using System;
using System.IO;
using System.Collections;
using System.Text.RegularExpressions;

namespace DataFileParser
{
    public class CDataFileParser
    {
        [System.Runtime.InteropServices.DllImport("kernel32.dll", SetLastError = true)]
        [return: System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.Bool)]
        static extern bool AllocConsole();

        [System.Runtime.InteropServices.DllImport("Kernel32")]
        static extern void FreeConsole();
        bool m_bConsoleOpened = false;
        ArrayList m_Data = new ArrayList();
        bool re = false;
        const string DefaultRegex = @"\w*\s*=\s*(-)?\d*.\d*\W";
//      const string DefaultRegex = @"\w*\s*=\s*\-?\d*.\d*";
        string m_Regex = DefaultRegex;
        //iStartLine和iEndLine都是从1开始，而数组都是从0开始：
        int iStartLine = 1;
        int iEndLine = -1;
        MatchCollection matches = null;

        public void OpenConsole()
        {
            if (m_bConsoleOpened)
            {
                Console.WriteLine("Error OpenConsole(): Console already opened! ");
                return;
            }
            AllocConsole();
            m_bConsoleOpened = true;
        }

        public void CloseConsole()
        {
            if (!m_bConsoleOpened)
            {
                Console.WriteLine("Error OpenConsole(): Console already closed! ");
                return;
            }
            FreeConsole();
            m_bConsoleOpened = false;
        }

        public void SetLineRange(int startline, int endline)
        {
            iStartLine = startline;
            iEndLine = endline;
        }

        public string GetRegex()
        {
            return m_Regex;
        }

        public string GetDefaultRegex()
        {
            return DefaultRegex;
        }

        public void SetDefaultRegex()
        {
            m_Regex = DefaultRegex;
        }

        public void SetRegex(string regex)
        {
            m_Regex = regex;
        }

        public bool ParseFile(string fname, int expectedndata)
        {
            StreamReader ifs = null;
            string alllines = "";
            string str = "";
            string[] strlines = null;
            string [] strs = null;
            int i = 0;
            int istart;
            try
            {
                //1. 清除数据缓存：
                m_Data.Clear();
                matches = null;
                ifs = new StreamReader(fname);
                //2. 开始读数据行：
                alllines = ifs.ReadToEnd();
                alllines = alllines.Replace("\r\n","\n");
                strlines = alllines.Split("\n");
                //3. 检查并设置起始行：
                //iStartLine和iEndLine都是从1开始，而数组都是从0开始：
                if (iStartLine <= 0 || iStartLine > strlines.Length)
                    iStartLine = 1;
                //4. 检查并设置终止行：
                if (iEndLine <= 0 || iEndLine > strlines.Length|| iEndLine < iStartLine)
                    iEndLine = strlines.Length;
                alllines = "";
                istart = iStartLine - 1;
                for (i = istart; i < iEndLine; i++)
                {
                    if(strlines[i].Length!=0) //过滤空行
                        alllines = alllines + strlines[i]+"\r\n";
                }
                //避免空行导致的崩溃：
                if (alllines.Length == 0)
                    throw new Exception("ParseFile() error: Empty lines encountered! ");
                //5. 用正则表达式找到全部有效的数据项（满足***=**.***的项）：
                //Regex :
                //@"\w*\s*=\s*\-?\d*.\d*"
                matches = Regex.Matches(alllines, m_Regex);
                if (matches.Count != expectedndata && expectedndata != 0)
                    throw new Exception("Error: invalid data count! ");
                int ndata = 0;
                //6. 获取数据：
                foreach (Match mm in matches)
                {
                    double dval = 0;
                    str = mm.Value.ToString();
                    strs = str.Split('=');
                    if (strs.Length == 1) dval = Convert.ToDouble(strs[0]);
                    if (strs.Length == 2) dval = Convert.ToDouble(strs[1]);
                    m_Data.Add(dval);
                    ndata++;
                }
                Console.WriteLine("Parsing data file \""+ fname + "\" OK! ["+ndata.ToString()+" items found!]");
                re = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                re = false;
            }
            finally
            {
                if (ifs != null) ifs.Close();
            }
            return re;
        }

        public string [] GetMatches()
        {
            string[] re=null;
            if (matches == null)
                return null;
            if (matches.Count == 0)
                return null;
            re = new string[matches.Count];
            Match mm = null;
            for(int i=0;i<matches.Count;i++)
            {
                mm = matches[i];
                re[i] = mm.Value.ToString();
            }
            return re;
        }

        public int GetDataCount()
        {
            if (m_Data == null) return 0;
            return m_Data.Count;
        }

        public double GetDataI(int i)
        {
            if (m_Data == null)
            {
                Console.WriteLine("Error from GetData(): Empty data buffer! You shall call ParseFile() first! ");
                return 0;
            }
            double re;
            re = (double) m_Data[i];
            return re;
        }

        public void Help()
        {
            string lines = "";
            lines = lines + "--------------------------------------------------------------------------------------------------\r\n";
            lines = lines + "This module will parse a data file using Regex and store it into a buffer. \r\n";
            lines = lines + "--------------------------------------------------------------------------------------------------\r\n";
            lines = lines + "1. Call \"void SetLineRange(int startline, int endline)\" to set range of lines to be parsed. \r\n";
            lines = lines + "\tIf SetLineRange() is not called, we will parse all data \r\n";
            lines = lines + "\tIf [startline <= 0] or [startline is greater than actual line count], we will parse from the first line \r\n";
            lines = lines + "\tIf [endline <= 0] or [endline is greater than actual line count] or [endline < startline]\r\n"+
                            "\twe will parse to the last line \r\n";
            lines = lines + "2. Call \"bool ParseFile(string fname, int expecteddata)\" to load and parse data file, \r\n" + 
                "\twhere the first parameter is file name and the second is number of expected data entries. \r\n\t";
            lines = lines + "If the number of expected data entries is 0, we will not validate the number of data entries. \r\n";
            lines = lines + "3. Call \"int GetDataCount()\" to get number of data entries in the buffer. \r\n";
            lines = lines + "4. Call \"double GetDataI(int i)\" to get the i-th data entry in the buffer. \r\n";
            lines = lines + "5. Call \"void SetRegex(string regex)\" to set regex for data entries. \r\n";
            lines = lines + "6. Call \"string GetRegex()\" to get current regex. \r\n";
            lines = lines + "7. Call \"void SetDefaultRegex()\" to set default regex for data entries. \r\n";
            lines = lines + "8. Call \"string GetDefaultRegex()\" to get default regex. \r\n";
            lines = lines + "9. Call \"string Help()\" for help. \r\n";
            lines = lines + "10. Call \"void OpenConsole()\" to open a console\r\n";
            lines = lines + "11. Call \"void CloseConsole()\" to close a console\r\n";
            lines = lines + "12. Call \"string [] GetMatches()\" to retrieve matched strings from regex\r\n";
            lines = lines + "--------------------------------------------------------------------------------------------------\r\n";
            lines = lines + "Data file parser by Hu Yu (julius_hu@hotmail.com). Ver.2022.05.25.1006\r\n";
            lines = lines + "--------------------------------------------------------------------------------------------------\r\n\r\n";
            Console.Write(lines);
        }
    }
}
